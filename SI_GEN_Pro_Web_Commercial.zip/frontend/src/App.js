
import React from 'react';
function App() {
  return (
    <div>
      <h1>SI-GEN Pro (Web)</h1>
      <button>Run S-Parameter Extraction</button>
    </div>
  );
}
export default App;
